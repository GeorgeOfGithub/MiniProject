import sys
from numba import jit
import numpy as np
from os.path import join
from optimized_code import load_data, summary_stats

@jit(nopython=True)
def jacobi(u, interior_mask, max_iter, atol=1e-6):
    u_old = np.copy(u)
    u_new = np.copy(u)
    rows, cols = u.shape
    
    for i in range(max_iter):
        delta = 0.0
        for r in range(1, rows - 1):
            for c in range(1, cols - 1):
                if interior_mask[r-1, c-1]:
                    val = 0.25 * (u_old[r, c-1] + u_old[r, c+1] + u_old[r-1, c] + u_old[r+1, c])
                    u_new[r, c] = val
                    diff = abs(u_old[r, c] - val)
                    if diff > delta:
                        delta = diff
                        
        u_old[:] = u_new[:]    
        if delta < atol:
            break         
    return u_new

@jit(nopython=True)
def do_jacobi(args):
    # Unpack arguments
    bid, load_dir, max_iter, abs_tol = args
    # Load data
    u0, interior_mask = load_data(load_dir, bid)

    # Do the jacobi iterations
    u = jacobi(u0, interior_mask, max_iter, abs_tol)

    # Calculate stats
    stats = summary_stats(u, interior_mask)
    return bid, stats

if __name__ == '__main__':
    # Load data
    LOAD_DIR = '/dtu/projects/02613_2025/data/modified_swiss_dwellings/'
    with open(join(LOAD_DIR, 'building_ids.txt'), 'r') as f:
        building_ids = f.read().splitlines()

    if len(sys.argv) < 2:
        N = 1
    else:
        N = int(sys.argv[1])
    
    building_ids = building_ids[:N]

    # Load floor plans
    all_u0 = np.empty((N, 514, 514))
    all_interior_mask = np.empty((N, 512, 512), dtype='bool')

    for i, bid in enumerate(building_ids):
        u0, interior_mask = load_data(LOAD_DIR, bid)
        all_u0[i] = u0
        all_interior_mask[i] = interior_mask

    # Run jacobi iterations for each floor plan
    MAX_ITER = 20_000
    ABS_TOL = 1e-4

    all_u = np.empty_like(all_u0)
    for i, (u0, interior_mask) in enumerate(zip(all_u0, all_interior_mask)):
        u = jacobi(u0, interior_mask, MAX_ITER, ABS_TOL)
        all_u[i] = u

    # Print summary statistics in CSV format
    stat_keys = ['mean_temp', 'std_temp', 'pct_above_18', 'pct_below_15']
    print('building_id, ' + ', '.join(stat_keys)) # CSV header
    
    for bid, u, interior_mask in zip(building_ids, all_u, all_interior_mask):
        stats = summary_stats(u, interior_mask)
        print(f"{bid}, " + ", ".join(str(stats[k]) for k in stat_keys))